Minimal reproducible example: ElectronicLoad connectedShare exported outside [0,1].

Run with any Dynawo v1.7.0 install:

    dynawo.sh jobs case.jobs

Then look at the three samples at t=1.100000 in outputs/curves/curves.csv
(column EL_load_connectedShare).
